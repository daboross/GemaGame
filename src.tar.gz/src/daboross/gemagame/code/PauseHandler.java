package daboross.gemagame.code;

public class PauseHandler {

	public PauseHandler() {

	}

}
